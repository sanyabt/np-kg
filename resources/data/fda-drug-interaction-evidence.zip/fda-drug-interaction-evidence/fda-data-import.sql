--create table for FDA data

create table staging_fda (
	id serial not null,
	chemical_name varchar(100),
	chemical_id varchar(20),
	protein_name varchar(50),
	protein_id varchar(20),
	relation_name varchar(50),
	relation_id varchar(20),
	cas_number varchar(50),
	AUC_percent_change float4,
	reference varchar(50)
)

alter table staging_fda
add primary key (id) 

--import data from CSV files 'sd-*-processed.csv' at NaPDI-pv/fda-drug-interaction-evidence/processed-data/
--convert nan values to null 

update staging_fda 
set chemical_id = null, protein_id = null, relation_id = null

update staging_fda 
set relation_name = null 
where relation_name = 'nan'

--map chemical names and protein names to IDs

update staging_fda 
set protein_id = mp.id 
from mapping_table mp
where mp."name" = staging_fda.protein_name and mp."type" = 'protein'

update staging_fda 
set protein_id = mp.id 
from mapping_table mp
where mp."name" = upper(staging_fda.protein_name) and mp."type" = 'protein'

update staging_fda 
set chemical_id = mp.id 
from mapping_table mp
where mp."name" = staging_fda.chemical_name and mp."type" = 'chemical' and staging_fda.chemical_id is NULL

update staging_fda 
set chemical_id = mp.id 
from mapping_table mp
where mp."name" = staging_fda.chemical_name and mp."type" = 'NP' and staging_fda.chemical_id is NULL

update staging_fda 
set chemical_id = chebi_names.chebi_id 
from chebi_names 
where lower(chebi_names.chemical_name) = staging_fda.chemical_name

select distinct sf.protein_name from staging_fda sf 
where sf.protein_id is null 

update staging_fda 
set protein_id = 'PR_P33260'
where protein_name = 'CYP2C18'

select distinct sf.chemical_name from staging_fda sf 
where sf.chemical_id is null 

update staging_fda 
set chemical_id = 'CHEBI_8426'
where chemical_name = 'probenecid'

update staging_fda 
set chemical_id = 'CHEBI_6375'
where chemical_name = 'lansoprazole'

delete from staging_fda 
where protein_name in ('acetylation', 'aldoketoreductases', 'Mitochondrial_-oxidation', 'Carbonylreductase', 'nonCYP-dependent', 'Biliaryexcretion', 'non-P450enzymes',
'Arylsulfatase', 'AO', 'Hydrolysis', 'NonP450metabolism', 'gluathionereduction', 'Esterase', 'AKR', 'CYP', 'SULT', 'UGT')

update staging_fda
set relation_name = 'transports'
where relation_name is NULL and protein_id in ('PR_Q96FL8', 'PR_Q86VL8', 'PR_Q4U2R8', 'PR_PR_Q8TCC7', 'PR_Q9Y6L6', 'PR_Q9NPD5', 'PR_Q14242', 'PR_O15245', 'PR_O15244')

update staging_fda
set relation_name = 'is_substrate_of'
where relation_name is NULL

--change chemical IDs to include 'CHEBI_' == also in DIKB
update staging_fda 
set chemical_id = concat('CHEBI_', chemical_id) 
where chemical_id not like 'CHEBI_%' and chemical_id not like 'PC_%' and chemical_id not like 'SRS_%'

--add relation IDs
update staging_fda 
set relation_id = mp.id 
from mapping_table mp
where mp."name" = staging_fda.relation_name and mp."type" = 'relation' and staging_fda.relation_id is NULL



