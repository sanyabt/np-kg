import pandas as pd
import sys, os
import numpy as np

working_dir = os.getcwd()
DIR_IN = working_dir + '/processed-data/'
file_i = DIR_IN + sys.argv[1]

#protein_mega = []

def process_data(df):
	df['protein_name_new'] = pd.Series(dtype='object')
	for i in range(0, len(df.index)):
		protein_name = df.at[i, 'protein_name']
		chemical_name = df.at[i, 'chemical_name']
		protein_list = protein_name.split(',')
		protein_list = [x.replace(' ', '') for x in protein_list]
		protein_list_unique = list(set(protein_list))
		#protein_mega.extend(protein_list_unique)
		df.at[i, 'protein_name_new'] = protein_list_unique

	df = df.drop(['protein_name'], axis=1)
	df.rename({'protein_name_new': 'protein_name'}, axis=1, inplace=True)
	lst_col = 'protein_name'

	df_new = pd.DataFrame({
		col:np.repeat(df[col].values, df[lst_col].str.len())
		for col in df.columns.difference([lst_col])
	}).assign(**{lst_col:np.concatenate(df[lst_col].values)})[df.columns.tolist()]

	return df_new

if __name__ == '__main__':
	df = pd.read_csv(file_i)
	df_new = process_data(df)

	'''with open(DIR_IN+'protein_list.txt', 'w') as file_o:
		for item in protein_mega:
			file_o.write(item+'\n')'''

	df_new.to_csv(file_i[:-4]+'-processed.csv', index=False)


